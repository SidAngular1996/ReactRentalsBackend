
var Validator = {}

Validator.validateEmployee = function(employeeId){
    var empId = new String(employeeId);
    var pattern =/^7[0-9]{5}/;
    if(!empId.match(pattern) ){
        throw new Error("Invalid! Employee Id must start with 7 and should be a 6 digit number");
    }else{
        console.log("done!!");
    }
}

Validator.validateDate = function(startDate,endDate){
    var today = new Date();
    var sdate = new Date(startDate);
    var edate = new Date(endDate)
    if(today.getTime()>sdate.getTime()){
        throw new Error("Ride Start Date cannot be before today's date");
    }
    if(edate.getTime()<sdate.getTime()){
        throw new Error("Ride end date cannot be before ride start date");
    }
}





module.exports = Validator;
