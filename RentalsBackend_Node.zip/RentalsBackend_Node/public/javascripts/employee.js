var employee  = function(employeeId,employeeName){
    this.employeeName = employeeName;
    this.employeeId = employeeId;
}

employee.toObject = function(result){
    return new employee(result.employeeId,result.employeeName);
}


module.exports = employee;