var rentedVehicle = require('./rentedVehicle')
var employee = require('./employee');
var connection = require('./connections');
var AllocatorDAL = {}

AllocatorDAL.checkEmployee = function (employeeId) {
    return connection.getConnection().then(function (db) {
        empId= parseInt(employeeId);
        return db.collection("Employee").findOne({"employeeId": empId }).then(function (result) {
            return result;
        }).catch(function (Error) {
            throw new Error("did not find employee!!");
        })
    }).catch(function (error) {
        throw new Error("did not find employee!!");
    })
}

AllocatorDAL.checkBooking = function(rentId){
    return connection.getConnection().then(function(db){
        return db.collection("vehicleRenting").findOne({"rentId":rentId}).then(function(result){
            return result;
        }).catch(function(Error){
            throw new Error("Rent Details not found");
        })
    }).catch(function(error){
        throw new Error("Rent Details not Found");
    })
}

AllocatorDAL.rentVehicle = function (rentedVehicle) {
    return connection.getConnection().then(function (db) {
        var my_collection = db.collection('vehicleRenting');
        return my_collection.distinct("rentId").then(function(ids){
            var max_rent_allocation_Id = Math.max(...ids);
            return my_collection.insert({
                "rentId":max_rent_allocation_Id+1, "employeeName": rentedVehicle.employeeName,
                "employeeId":rentedVehicle.employeeId,"vehicleType":rentedVehicle.vehicleType,
                "startDate":rentedVehicle.startDate,"startTime":rentedVehicle.startTime,"endDate":rentedVehicle.endDate,
                "rentAmount":rentedVehicle.rentAmount
            }).then(function(result){
                if(!result) console.log("details not saved!!");
                else return result;
            })
        }) 
    })
}

AllocatorDAL.fetchDetails = function (employeeId) {
    empId=parseInt(employeeId)
    return connection.getConnection().then(function (db) {
        return db.collection("vehicleRenting").find({"employeeId": empId }).toArray().then(function (result) {
            console.log("DL")
            return result;
        }).catch(function (Error) {
            throw new Error("did not find details!!");
        })
    }).catch(function (error) {
        throw new Error("did not find details!!");
    })
}


AllocatorDAL.modify= function (rentDetails,newDate){
    return connection.getConnection().then(function(db){
        var my_collection=db.collection('vehicleRenting');
        return my_collection.updateMany( 
            {  "rentId" : rentDetails.rentId }, 
            {  $set: {  "endDate" : newDate,"rentAmount":rentDetails.rentAmount }  }
        ).then(function(result){
            if(!result) console.log("details not saved!!");
            else {
                rentDetails.endDate=newDate;
                return rentDetails
            }
        })
    })
}
   
module.exports = AllocatorDAL;
 