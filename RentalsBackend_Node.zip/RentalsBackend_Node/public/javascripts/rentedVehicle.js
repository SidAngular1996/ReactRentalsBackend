var rentedVehicle  = function(rId,ename,empId,vType,sDate,sTime,eDate,ramt){
    this.rentId = rId;
    this.employeeName = ename;
    this.startDate = sDate;
    this.startTime=sTime;
    this.endDate = eDate;
    this.vehicleType = vType;
    this.employeeId = empId;
    this.rentAmount = ramt;
}

rentedVehicle.toObject = function(result){
    return new rentedVehicle(result.rentId,result.employeeName,result.employeeId,result.vehicleType,result.startDate,result.startTime,result.endDate,result.rentAmount);
}

module.exports = rentedVehicle;