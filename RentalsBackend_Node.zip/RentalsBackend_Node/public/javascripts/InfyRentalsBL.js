var rentedVehicle = require('./rentedVehicle');
var InfyRentalsDAL = require('./InfyRentalsDAL');
var Validator = require('./Validator');

var InfyrentalsBL={}
InfyrentalsBL.calculateRent = function(vehicle,endDate){
    dt1 = new Date(vehicle.startDate);
    dt2 = new Date(endDate);
    console.log(endDate+dt1)
    duration= Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate()) ) /(1000 * 60 * 60 * 24));
    if(vehicle.vehicleType=="4Wheeler"){
        vehicle.rentAmount = 1000*duration;
    }else if(vehicle.vehicleType=="2Wheeler"){
        vehicle.rentAmount = 500*duration;
    }else{
        vehicle.rentAmount = 0 ;
    }
}

InfyrentalsBL.rent = function(vehicle){
    Validator.validateEmployee(vehicle.employeeId);
    return InfyRentalsDAL.checkEmployee(vehicle.employeeId).then(function(employee){
        if(employee == null){
            throw new Error("The given Employee doesnot exist!! Renting is unauthorized!!");
        }else{
            if(employee.employeeName!=vehicle.employeeName){
                throw new Error("Employee Id and Employee Name do not match!!")
            }
            else{
                Validator.validateDate(vehicle.startDate,vehicle.endDate);
                InfyrentalsBL.calculateRent(vehicle,vehicle.endDate);
                promise = InfyRentalsDAL.rentVehicle(vehicle);
                return promise;
            }
        }
    }).then(function (vehicleFromDL) {
        return vehicleFromDL;
    })
}

InfyrentalsBL.fetchDetails = function(empId){
    Validator.validateEmployee(empId);
    return InfyRentalsDAL.checkEmployee(empId).then(function(employee){
        if(employee == null){
            throw new Error("The given Employee does not exist!!");
        }else{
            return InfyRentalsDAL.fetchDetails(empId).then(function(rentDetails){
                console.log(rentDetails)
                if(rentDetails.length==0){
                    throw new Error("No booking found!!");
                }
                else{
                    console.log("BL")
                    return rentDetails;
                }
            })
        }
    })
}

InfyrentalsBL.modify = function(rentId){
    console.log(typeof rentId)
    return InfyRentalsDAL.checkBooking(parseInt(rentId)).then(function(rentDetails){
        if(rentDetails == null){
            throw new Error("No details Found");
        }else{
            oldRentAmount=rentDetails.rentAmount;
            newDate=new Date(rentDetails.endDate);
            newDate.setDate(newDate.getDate()+1);
            InfyrentalsBL.calculateRent(rentDetails,newDate);
            return InfyRentalsDAL.modify(rentDetails,newDate).then(function(newRentDetails){
                return newRentDetails.rentAmount-oldRentAmount;
            });
        }
     })
}

module.exports = InfyrentalsBL;