var express = require('express');
var routing = express.Router();

var InfyrentalsBL = require('../public/javascripts/InfyRentalsBL');
var rentedVehicle = require('../public/javascripts/rentedVehicle');

routing.post('/rent', function(req,res,next){
    var assign = rentedVehicle.toObject(req.body);
    InfyrentalsBL.rent(assign).then(function(vehicle){
        res.json({"message":"A "+vehicle.ops[0].vehicleType+" with rentId "+vehicle.ops[0].rentId+" successfully allocated to employee "+vehicle.ops[0].employeeId+" You Need to pay Rs."+vehicle.ops[0].rentAmount}) 
    }).catch(function (err) {
        next(err);
    })
})

routing.get('/vehicleRenting/:empid', function(req,res,next){
    var empId= req.params.empid
    InfyrentalsBL.fetchDetails(empId).then(function(rentDetails){
        console.log("routing")
        res.send(rentDetails); 
    }).catch(function (err) {
        next(err);
    })
})

routing.get('/extend/:rentId', function(req,res,next){
    var rentId= req.params.rentId
    InfyrentalsBL.modify(rentId).then(function(rentAmount){
        res.json({"message":"Ride end date extended by one day!! Amount to be paid: "+rentAmount})
    }).catch(function(err){
        next(err);
    })
})

module.exports = routing;